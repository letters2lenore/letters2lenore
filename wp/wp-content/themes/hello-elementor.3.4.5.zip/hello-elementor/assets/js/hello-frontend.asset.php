<?php return array('dependencies' => array(), 'version' => '3e6f99ff76f28dfea8c2');
