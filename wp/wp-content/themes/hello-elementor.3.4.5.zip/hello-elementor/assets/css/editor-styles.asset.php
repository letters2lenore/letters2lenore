<?php return array('dependencies' => array(), 'version' => '377baf681f2138bc7e58');
